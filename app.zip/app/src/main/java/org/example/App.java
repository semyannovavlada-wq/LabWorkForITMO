package org.example;

import org.example.cli.services.CommandService;
import org.example.cli.services.LoopService;
import org.example.services.MeasurementService;
import org.example.services.ProtocolService;
import org.example.services.SampleService;
import org.example.storage.AppData;
import org.example.storage.StorageService;

import java.nio.file.Path;

public class App {

    public static void main(String[] args) {
        if (args.length > 0) {
            AppData.setCustomFolder(Path.of(args[0]));
            System.out.println("Using data directory: " + args[0]);
        }

        System.out.println("type help for help");

        SampleService sampleService = new SampleService();
        MeasurementService measurementService = new MeasurementService(sampleService);
        ProtocolService protocolService = new ProtocolService(sampleService, measurementService);

        StorageService storageService = new StorageService(sampleService, measurementService, protocolService);

        storageService.loadAll();

        Runtime.getRuntime().addShutdownHook(new Thread(storageService::saveAll));

        CommandService commandService = new CommandService(sampleService, measurementService, protocolService);

        LoopService loopService = new LoopService(commandService);
        loopService.loopOfCommands();
    }
}