plugins {
    application
}

repositories {
    mavenCentral()
}

dependencies {
    testImplementation(libs.junit.jupiter)
    testRuntimeOnly("org.junit.platform:junit-platform-launcher")
    implementation(libs.guava)
    implementation("com.google.code.gson:gson:2.10.1")

    // JavaFX
    implementation("org.openjfx:javafx-controls:23.0.2")
    implementation("org.openjfx:javafx-base:23.0.2")
    implementation("org.openjfx:javafx-graphics:23.0.2")
}

java {
    toolchain {
        languageVersion = JavaLanguageVersion.of(21)
    }
}

application {
    applicationDefaultJvmArgs = listOf(
        "--add-modules", "javafx.controls,javafx.base,javafx.graphics"
    )
    mainClass = "org.example.ui.AppFX"
}

tasks.named<Test>("test") {
    useJUnitPlatform()
}

tasks.withType<JavaExec> {
    standardInput = System.`in`
    systemProperty("file.encoding", "UTF-8")
}